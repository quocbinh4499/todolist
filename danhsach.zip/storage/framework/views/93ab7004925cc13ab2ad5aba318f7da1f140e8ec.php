<?php $__env->startSection('content'); ?>

    ĐANG SỬA CÔNG VIỆC:
    
    <button type="button" class="btn btn-warning">
        <?php echo e($congviec->name); ?>

    </button>
    <hr>

    <div class="row">
        <div class="col-lg-12 col-lg-offset-3" >
            <form action="<?php echo e(route('cv.update',['id'=>$congviec->id])); ?>">
                <input type="text" class="form-control input-lg" name="name" placeholder="Nhập công việc !!!" value="<?php echo e($congviec->name); ?>" >
            </form>    
        </div>
    </div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>