<?php $__env->startSection('content'); ?>

    Danh sách công việc 

    <br>
    <hr>

    <div class="row">
        <div class="col-lg-12 col-lg-offset-3" >
            <form action="<?php echo e(route('cv.create')); ?>">
                <input type="text" class="form-control input-lg" name="name" placeholder="Nhập công việc !!!" >
            </form>    
        </div>
    </div>

    <?php echo $__env->make('list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>