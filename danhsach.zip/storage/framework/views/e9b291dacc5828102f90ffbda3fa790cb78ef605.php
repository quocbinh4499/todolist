<?php $__currentLoopData = $Congviec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

    <div>

        <?php echo e($cv -> name); ?>

        <a style="color: #FFF" href="<?php echo e(route('cv.delete',['id' => $cv->id])); ?>" class="btn btn-xs btn-danger">xóa</a>
        <a style="color: #FFF" href="<?php echo e(route('cv.edit',['id' => $cv->id])); ?>" class="btn btn-xs btn-info">sửa</a>
        <?php if($cv ->complete == 'complete' ): ?>
            <span>Hoàn thành</span>
        <?php else: ?>
            <a style="color: #FFF" href="<?php echo e(route('cv.complete',['id' => $cv->id])); ?>" class="btn btn-xs btn-success">Hoàn thành</a>
        <?php endif; ?>
        <hr>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>