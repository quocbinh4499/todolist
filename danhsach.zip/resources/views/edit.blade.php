@extends('layouts/app')


@section('content')

    ĐANG SỬA CÔNG VIỆC:
    
    <button type="button" class="btn btn-warning">
        {{ $congviec->name}}
    </button>
    <hr>

    <div class="row">
        <div class="col-lg-12 col-lg-offset-3" >
            <form action="{{ route('cv.update',['id'=>$congviec->id])}}">
                <input type="text" class="form-control input-lg" name="name" placeholder="Nhập công việc !!!" value="{{ $congviec->name}}" >
            </form>    
        </div>
    </div>

    

@stop