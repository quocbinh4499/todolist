@extends('layouts/app')


@section('content')

    Danh sách công việc 

    <br>
    <hr>

    <div class="row">
        <div class="col-lg-12 col-lg-offset-3" >
            <form action="{{ route('cv.create')}}">
                <input type="text" class="form-control input-lg" name="name" placeholder="Nhập công việc !!!" >
            </form>    
        </div>
    </div>

    @include('list')

@stop