@foreach($Congviec as $cv)

    <div>

        {{$cv -> name}}
        <a style="color: #FFF" href="{{route('cv.delete',['id' => $cv->id])}}" class="btn btn-xs btn-danger">xóa</a>
        <a style="color: #FFF" href="{{route('cv.edit',['id' => $cv->id])}}" class="btn btn-xs btn-info">sửa</a>
        @if($cv ->complete == 'complete' )
            <span>Hoàn thành</span>
        @else
            <a style="color: #FFF" href="{{route('cv.complete',['id' => $cv->id])}}" class="btn btn-xs btn-success">Hoàn thành</a>
        @endif
        <hr>

    </div>

@endforeach