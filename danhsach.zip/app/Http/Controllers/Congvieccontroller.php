<?php

namespace App\Http\Controllers;

use App\Congviec;
use Illuminate\Http\Request;

class Congvieccontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $congviec = Congviec::all();
        return view('welcome')->with('Congviec',$congviec);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $congviec = new Congviec();

        $congviec->name = $request->name;

        $congviec->save();

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $congviec = Congviec::find($id);
        $list = Congviec::all();

        return view('edit')->with('congviec',$congviec);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $congviec = Congviec::find($id);

        $congviec-> name = $request->name;
        $congviec->complete = 'not';


        $congviec->save();

        return redirect()->route('home');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $congviec = Congviec::find($id);

        $congviec->delete();

        return redirect()->back();
    }
    public function complete($id)
    {
        $congviec = Congviec::find($id);

        $congviec->complete = 'complete';

        $congviec->save();


        return redirect()->back();

    }
}
