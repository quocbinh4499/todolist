<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', [
    'uses'=>'Congvieccontroller@index',
    'as'=>'home'
]);

Route::get('/create', [
    'uses'=>'Congvieccontroller@store',
    'as'=>'cv.create'
]);

Route::get('/delete/{id}', [
    'uses'=>'Congvieccontroller@destroy',
    'as'=>'cv.delete'
]);
Route::get('/edit/{id}', [
    'uses'=>'Congvieccontroller@edit',
    'as'=>'cv.edit'
]);
Route::get('/update/{id}', [
    'uses'=>'Congvieccontroller@update',
    'as'=>'cv.update'
]);
Route::get('/complete/{id}', [
    'uses'=>'Congvieccontroller@complete',
    'as'=>'cv.complete'
]);
